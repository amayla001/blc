# ui/__init__.py
# Fichier vide, nécessaire pour que Python traite le dossier comme un package
